/**
 * aui-popup.js
 * @author
 * @todo more things to abstract, e.g. Loading css etc.
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 */
(function( window, undefined ) {
    "use strict";
    var customLoading = function() {};
    customLoading.prototype = {
        params: {
            content:"加载中..."
        },
        create: function(params,callBack) {
            var self = this;
            if(document.querySelector(".loading_toast:not(.loading_toast_out)")){
                document.querySelector(".loading_toast").getElementsByTagName("p")[0].innerHTML=params?params:self.params.content;
                self.open(callBack);
            }else{
                var toastHtml= '<div onclick="top.isCloseCurrentWin($(\'body\').attr(\'class\'));" class="loading_toast"><i class="loading_icon"></i><p class="loading_content">'+(params?params:self.params.content)+'</p></div>';
                document.body.insertAdjacentHTML('beforeend', toastHtml);
                self.open(callBack);
            }
        },
        open: function(callBack){
            if(!document.querySelector(".loading_toast"))return;
            document.querySelector(".loading_toast").style.marginTop =  "-"+Math.round(document.querySelector(".loading_toast").offsetHeight/2)+"px";
            if(!document.querySelector(".aui-mask")){
                var maskHtml = '<div class="aui-mask"></div>';
                document.body.insertAdjacentHTML('beforeend', maskHtml);
            }
            setTimeout(function(){
                document.querySelector(".aui-mask").classList.add("aui-mask-in");
                document.querySelector(".loading_toast").classList.remove("loading_toast_out");
                document.querySelector(".loading_toast").classList.add("loading_toast_in");
            }, 10);
            document.querySelector(".aui-mask").addEventListener("touchmove", function(e){
                e.preventDefault();
            });
            document.querySelector(".loading_toast").addEventListener("touchmove", function(e){
                e.preventDefault();
            });
            callBack&&callBack();
            return;
        },
        close: function(callback){
            var self = this;
            document.querySelector(".aui-mask").classList.remove("aui-mask-in");
            document.querySelector(".loading_toast").classList.add("loading_toast_out");
            document.querySelector(".loading_toast").classList.remove("loading_toast_in");

            if (document.querySelector(".loading_toast.loading_toast_out")) {
                document.querySelector(".loading_toast").addEventListener(whichTransitionEvent(), function(){
                    self.remove(callback);
                });
                document.querySelector(".aui-mask").classList.add("aui-mask-out");
            }else{
                document.querySelector(".aui-mask").classList.add("aui-mask-out");
                setTimeout(function(){
                    if(document.querySelector(".loading_toast"))document.querySelector(".loading_toast").parentNode.removeChild(document.querySelector(".loading_toast"));
                    document.querySelector(".aui-mask").classList.remove("aui-mask-out");
                    //self.open();
                    callback&&callback();
                    return true;
                },200)
            }
        },
        remove: function(callback){
            if(document.querySelector(".loading_toast.loading_toast_out"))document.querySelector(".loading_toast").parentNode.removeChild(document.querySelector(".loading_toast.loading_toast_out"));
            if(document.querySelector(".aui-mask")){
                document.querySelector(".aui-mask").classList.remove("aui-mask-out");
            }
            callback&&callback();
            //this.open();
            return true;
        },
        start:function(params,callBack){
            var self = this;
            return self.create(params,callBack);
        }
    };
	window.customLoading = customLoading;
})(window);

//Loading....
var loading = new customLoading({});
function openLoadingToast(content,callBack){
    //loading.start(content,callBack);
    loading.start('已加载 <span id="icon_progress">0</span>%',callBack);
}
function closeLoadingToast(callback){
    document.querySelector(".loading_toast")&&loading.close(callback);
}
//setTimeout(function(){openLoadingToast()},100);
//setTimeout(function(){closeLoadingToast()},1500);